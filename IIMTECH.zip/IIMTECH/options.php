<?php 






//phone
$wphone = '8003177087';

//logo
$logosrc = '/wp-content/uploads/2016/07/mundilogo.png';

//email
$wemail = 'info@mundilimos.com';


$booknow = 'https://book.mylimobiz.com/v4/mundilimo';

$facebooka ='https://www.facebook.com/mundilimos';

$twittera ='https://twitter.com/mundilimos';

$linkedina ='https://www.linkedin.com/company/mundi-limos';

$googleplusa ='https://plus.google.com/+mundiLimos';

$youtubea ='https://www.youtube.com/channel/UClHIHKPbVOfFFCr4BYGvVfw';

















































?>